# SmartTrade AI

Private, AI-powered IQ Option forex chart analysis terminal.

## Features
- Upload IQ Option forex chart screenshots (`PNG`, `JPG`, `JPEG`) via tap, drag-and-drop, or clipboard paste.
- Genuine multimodal AI Vision inspection (supports **Google Gemini**, **Groq**, **OpenAI**, and **OpenRouter**).
- Identifies candlestick patterns, trend structure, support & resistance, momentum, and visible technical indicators without inventing prices or unseen indicators.
- Generates **exactly two calibrated trading predictions** (`CALL` in green, `PUT` in red) with confidence score (`0–100%`), entry condition, recommended expiry time, and technical explanation — plus automatic **NO TRADE** protection when market structure is choppy or unclear.
- Built-in **Saved Predictions**, **Analysis History**, and personal outcome tracking.
- **Analysis-only**: never connects to a broker account and never executes trades automatically.

## Run Locally
```bash
python3 app.py
```
Open `http://localhost:8000`.

## Optional Environment Variables (for Render / Cloud Hosting)
- `GEMINI_API_KEY` (or `GROQ_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY`) — keeps your AI Vision key configured permanently across restarts.
- `SMARTTRADE_PASSCODE` — optional PIN/passcode if you want to lock access on a public URL.
- `SMARTTRADE_DATA_DIR` — custom folder path for SQLite database and uploaded chart images.
