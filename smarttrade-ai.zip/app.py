#!/usr/bin/env python3
"""SmartTrade AI — Private AI-Powered Forex & Fixed-Time Chart Analysis Server.

Pure Python 3 standard library implementation (zero third-party pip packages required).
Provides:
  - Genuine multimodal AI Vision chart analysis (Google Gemini, Groq, OpenAI, OpenRouter)
  - Strict anti-hallucination structured JSON prompt & validation
  - Server-side API key vault & environment variable integration (keys never sent to client)
  - PNG/JPEG binary header verification & dimension inspection
  - SQLite persistence for analysis history, saved predictions, and outcome tracking
  - Analysis-only architecture: never connects to brokers or executes trades
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import ssl
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from contextlib import contextmanager
from datetime import datetime, timezone
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
DATA_DIR = Path(os.getenv("SMARTTRADE_DATA_DIR", str(ROOT / "data"))).expanduser().resolve()
UPLOADS_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "smarttrade.sqlite3"
SECRETS_PATH = DATA_DIR / "api_keys.json"

ACCESS_PASSCODE = os.getenv("SMARTTRADE_PASSCODE", "").strip()
MAX_UPLOAD_BYTES = 12 * 1024 * 1024  # 12 MB max chart screenshot

ALLOWED_PAIRS = [
    "EUR/USD",
    "EUR/USD (OTC)",
    "GBP/USD",
    "GBP/USD (OTC)",
    "USD/JPY",
    "USD/JPY (OTC)",
    "AUD/USD",
    "USD/CAD",
    "USD/CHF",
    "EUR/GBP",
    "EUR/JPY",
    "GBP/JPY",
    "NZD/USD",
    "XAU/USD",
]
ALLOWED_TIMEFRAMES = ["15s", "30s", "1m", "2m", "5m", "15m", "30m", "1h", "4h"]
ALLOWED_EXPIRIES = ["1m", "2m", "3m", "5m", "10m", "15m", "30m", "1h"]
ALLOWED_STRATEGIES = ["Conservative", "Balanced", "Price-Action Strict"]

_gemini_model_cache: dict[str, tuple[float, list[str]]] = {}
_sessions: dict[str, float] = {}
_lock = threading.Lock()


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def new_id(prefix: str = "ST") -> str:
    return f"{prefix}-{int(time.time())}-{secrets.token_hex(4).upper()}"


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(DATA_DIR, 0o700)
        os.chmod(UPLOADS_DIR, 0o700)
    except OSError:
        pass


@contextmanager
def db_conn():
    ensure_dirs()
    conn = sqlite3.connect(DB_PATH, timeout=15)
    try:
        os.chmod(DB_PATH, 0o600)
    except OSError:
        pass
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with db_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS analyses (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                currency_pair TEXT NOT NULL,
                detected_pair TEXT,
                timeframe TEXT NOT NULL,
                trade_duration TEXT NOT NULL,
                strategy TEXT NOT NULL,
                user_note TEXT,
                image_filename TEXT NOT NULL,
                image_mime TEXT NOT NULL,
                image_width INTEGER NOT NULL,
                image_height INTEGER NOT NULL,
                provider_used TEXT NOT NULL,
                model_used TEXT NOT NULL,
                overall_verdict TEXT NOT NULL,
                no_trade_reason TEXT,
                market_summary TEXT NOT NULL,
                analysis_json TEXT NOT NULL,
                is_saved INTEGER NOT NULL DEFAULT 0,
                outcome TEXT NOT NULL DEFAULT 'pending',
                trader_note TEXT NOT NULL DEFAULT ''
            );

            CREATE INDEX IF NOT EXISTS idx_analyses_created_at
                ON analyses(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_analyses_saved
                ON analyses(is_saved DESC, created_at DESC);
            """
        )


# ---------------------------------------------------------------------------
# API Key Vault (Environment Variables take priority, fallback to local file)
# ---------------------------------------------------------------------------

def _read_stored_secrets() -> dict[str, str]:
    if not SECRETS_PATH.exists():
        return {}
    try:
        raw = json.loads(SECRETS_PATH.read_text("utf-8"))
        if isinstance(raw, dict):
            return {str(k): str(v) for k, v in raw.items() if v}
    except Exception:
        pass
    return {}


def _write_stored_secrets(data: dict[str, str]) -> None:
    ensure_dirs()
    SECRETS_PATH.write_text(json.dumps(data, indent=2), "utf-8")
    try:
        os.chmod(SECRETS_PATH, 0o600)
    except OSError:
        pass


def detect_provider_from_key(api_key: str) -> str:
    key = api_key.strip()
    if key.startswith("AIza"):
        return "gemini"
    if key.startswith("gsk_"):
        return "groq"
    if key.startswith("sk-or-"):
        return "openrouter"
    if key.startswith("sk-"):
        return "openai"
    return "gemini"


def get_active_ai_credentials() -> dict[str, Any]:
    """Resolve active AI Vision provider and key. Never expose full key to callers."""
    env_candidates = [
        ("gemini", os.getenv("GEMINI_API_KEY", "").strip() or os.getenv("GOOGLE_API_KEY", "").strip()),
        ("groq", os.getenv("GROQ_API_KEY", "").strip()),
        ("openai", os.getenv("OPENAI_API_KEY", "").strip()),
        ("openrouter", os.getenv("OPENROUTER_API_KEY", "").strip()),
    ]
    custom_model = os.getenv("SMARTTRADE_AI_MODEL", "").strip()
    for provider, key in env_candidates:
        if key:
            return {
                "configured": True,
                "source": "environment",
                "provider": provider,
                "api_key": key,
                "masked_key": mask_secret(key),
                "custom_model": custom_model,
            }

    stored = _read_stored_secrets()
    key = stored.get("api_key", "").strip()
    if key:
        provider = stored.get("provider") or detect_provider_from_key(key)
        return {
            "configured": True,
            "source": "vault",
            "provider": provider,
            "api_key": key,
            "masked_key": mask_secret(key),
            "custom_model": stored.get("custom_model", "").strip() or custom_model,
        }

    return {
        "configured": False,
        "source": None,
        "provider": None,
        "api_key": "",
        "masked_key": None,
        "custom_model": custom_model,
    }


def mask_secret(key: str) -> str:
    if len(key) <= 8:
        return "••••••••"
    return f"{key[:4]}••••••••{key[-4:]}"


# ---------------------------------------------------------------------------
# Pure-Python PNG & JPEG Binary Validation & Dimension Extraction
# ---------------------------------------------------------------------------

def inspect_image_bytes(data: bytes) -> tuple[str, int, int]:
    """Validate real PNG or JPEG headers and extract (mime, width, height)."""
    if len(data) < 32:
        raise ValueError("Uploaded file is too small or empty.")

    # PNG signature: 89 50 4E 47 0D 0A 1A 0A
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        if data[12:16] != b"IHDR":
            raise ValueError("Invalid PNG header structure.")
        width, height = struct.unpack(">II", data[16:24])
        if width <= 0 or height <= 0:
            raise ValueError("Invalid PNG image dimensions.")
        return ("image/png", int(width), int(height))

    # JPEG signature: FF D8 FF
    if data[:3] == b"\xff\xd8\xff":
        idx = 2
        length = len(data)
        sof_markers = {
            0xC0, 0xC1, 0xC2, 0xC3,
            0xC5, 0xC6, 0xC7,
            0xC9, 0xCA, 0xCB,
            0xCD, 0xCE, 0xCF,
        }
        while idx < length - 9:
            if data[idx] != 0xFF:
                idx += 1
                continue
            while idx < length and data[idx] == 0xFF:
                idx += 1
            if idx >= length:
                break
            marker = data[idx]
            idx += 1
            if marker in {0xD8, 0xD9} or (0xD0 <= marker <= 0xD7) or marker == 0x01:
                continue
            if idx + 2 > length:
                break
            seg_len = struct.unpack(">H", data[idx:idx + 2])[0]
            if seg_len < 2 or idx + seg_len > length:
                break
            if marker in sof_markers:
                if idx + 7 > length:
                    break
                height, width = struct.unpack(">HH", data[idx + 3:idx + 7])
                if width > 0 and height > 0:
                    return ("image/jpeg", int(width), int(height))
            idx += seg_len
        raise ValueError("Could not read JPEG dimensions. Please upload a valid JPG/PNG screenshot.")

    raise ValueError("Unsupported file format. Please upload a PNG, JPG, or JPEG chart screenshot.")


# ---------------------------------------------------------------------------
# AI Vision Prompt & Strict Anti-Hallucination Schema
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are SmartTrade AI, an institutional-grade quantitative forex & fixed-time (IQ Option style) technical chart analyst.

CRITICAL ACCURACY & ANTI-HALLUCINATION RULES (MANDATORY):
1. EXAMINE ONLY WHAT IS VISUALLY PRESENT IN THE UPLOADED IMAGE.
2. NEVER invent, guess, or fabricate prices, exchange rates, axis labels, indicator values, moving averages, RSI readings, or candlestick patterns that are not visibly present in the screenshot.
3. If the uploaded image is NOT a financial/forex trading chart, OR is too blurry/cropped/obscured to read candlestick structure:
   - Set "is_valid_chart" to false.
   - Set "overall_verdict" to "NO TRADE".
   - Explain clearly in "no_trade_reason" why the image cannot be analysed safely.
   - Set both predictions' "direction" to "NO TRADE" and "confidence" to 0.
4. If the price axis on the right edge is cropped or unreadable, state "Price axis not legible in screenshot" for price levels and define entries strictly by visual candlestick triggers (e.g., "Bullish close above the recent 3-candle high") — NEVER make up numbers like 1.08450 unless those digits are legible on the chart.
5. For "indicators_observed": ONLY list technical indicators actually drawn on the screenshot (e.g., Moving Averages, Bollinger Bands, RSI, MACD, Stochastic, Parabolic SAR, Alligator, Volume). If none are drawn, return ["None visible on chart (pure price-action chart)"].
6. Check if the chart label shows "(OTC)" (IQ Option Over-The-Counter weekend/synthetic feed) or a different currency pair/timeframe than the user's selected settings, and note any mismatch honestly in "chart_metadata.mismatch_warning".
7. STRATEGY DISCIPLINE:
   - "Conservative": Demand clear multi-factor confluence (trend alignment + clean S/R level + clear candle rejection/momentum). If price is mid-range, choppy with long overlapping wicks on both sides, or fighting counter-trend momentum, set "overall_verdict" to "NO TRADE" and explain what confirmation to wait for.
   - "Balanced": Require solid structure + candle trigger; flag moderate-risk counter-trend setups as conditional.
   - "Price-Action Strict": Focus heavily on raw OHLC market structure, liquidity sweeps, pin bars/engulfing candles, and horizontal supply/demand zones.
8. EXACTLY TWO PREDICTIONS REQUIRED:
   Always return an array "predictions" of EXACTLY 2 items:
   - Prediction 1 ("Primary Setup"): The highest-probability directional setup (CALL or PUT) supported by current or imminent price action, with realistic calibrated confidence (0-100%), concrete entry point/condition, recommended expiry time, and concise technical rationale. (Only use direction "NO TRADE" with confidence 0 if the image itself is not a readable trading chart.)
   - Prediction 2 ("Alternative / Conditional Scenario"): The second potential trading prediction — either a key invalidation/reversal setup (opposite direction if a key S/R level breaks or rejects) OR a secondary pullback/continuation entry — with its own CALL or PUT direction, realistic confidence (0-100%), exact trigger condition required before entering, recommended expiry time, and technical explanation.
   - IMPORTANT: If "overall_verdict" is "NO TRADE" on a readable chart (because current candle action is choppy/unconfirmed), mark both predictions' "status" as "WAIT FOR TRIGGER" (instead of "ACTIVE SETUP") and keep confidence conservative (<58%) so the user knows NOT to enter immediately unless the specific trigger occurs.

Return ONLY valid JSON matching this exact structure (no markdown fences, no commentary outside JSON):
{
  "is_valid_chart": true,
  "overall_verdict": "ACTIONABLE" | "NO TRADE",
  "no_trade_reason": "Null or empty string if ACTIONABLE; otherwise a clear, specific explanation of why standing aside right now is safer.",
  "market_summary": "2-3 sentence executive technical assessment of the exact chart uploaded.",
  "chart_metadata": {
    "detected_pair": "Exact pair text read from chart (e.g. 'EUR/USD' or 'EUR/USD (OTC)') or 'Not legible'",
    "detected_timeframe": "Exact candle timeframe read from chart or 'Not legible'",
    "visible_current_price": "Exact highlighted current price on right axis or 'Not legible'",
    "chart_clarity": "High" | "Medium" | "Low",
    "mismatch_warning": "Empty string if matches user settings, or clear note if chart shows a different pair/timeframe/OTC feed."
  },
  "technical_breakdown": {
    "trend": {
      "primary_bias": "Bullish" | "Bearish" | "Ranging / Sideways" | "Unclear",
      "structure_detail": "Detailed observation of swing highs/lows and micro-trend."
    },
    "candlestick_patterns": [
      {
        "name": "Pattern or candle behaviour name",
        "location": "Where on chart (e.g. 'Rightmost 2 candles at resistance')",
        "implication": "Bullish" | "Bearish" | "Neutral / Indecision",
        "detail": "Specific wick/body observation"
      }
    ],
    "support_resistance": {
      "resistance_levels": ["Exact visible price + context, or visual zone description if axis cropped"],
      "support_levels": ["Exact visible price + context, or visual zone description if axis cropped"],
      "price_position": "Where current price sits relative to visible S/R"
    },
    "momentum": {
      "state": "Strong Bullish" | "Moderate Bullish" | "Neutral / Compressing" | "Moderate Bearish" | "Strong Bearish" | "Choppy / Conflicting",
      "detail": "Candle body size progression, impulse vs pullback speed, wick rejection pressure."
    },
    "indicators_observed": [
      "Exact indicator and reading visible on screenshot, OR 'None visible on chart (pure price-action chart)'"
    ],
    "risk_factors": [
      "Specific technical risk visible on this chart (e.g. 'Long upper wicks showing seller absorption near resistance')"
    ]
  },
  "predictions": [
    {
      "slot": 1,
      "label": "Primary Prediction",
      "direction": "CALL" | "PUT" | "NO TRADE",
      "status": "ACTIVE SETUP" | "WAIT FOR TRIGGER" | "DO NOT ENTER",
      "confidence": 72,
      "entry_condition": "Specific price level (only if visible) + exact candle confirmation condition",
      "recommended_expiry": "e.g. 5 minutes (1 candle close)",
      "explanation": "Concise, concrete technical reasoning tied directly to visible chart elements."
    },
    {
      "slot": 2,
      "label": "Secondary / Conditional Prediction",
      "direction": "CALL" | "PUT" | "NO TRADE",
      "status": "WAIT FOR TRIGGER" | "ACTIVE SETUP" | "DO NOT ENTER",
      "confidence": 54,
      "entry_condition": "Specific breakout/rejection level + confirmation required before considering entry",
      "recommended_expiry": "e.g. 5-10 minutes",
      "explanation": "Concise technical reasoning for this alternative or confirmation scenario."
    }
  ]
}"""


def build_user_prompt(pair: str, timeframe: str, expiry: str, strategy: str, user_note: str) -> str:
    lines = [
        "Analyse this uploaded IQ Option / forex chart screenshot strictly using visual evidence.",
        f"- User-selected Currency Pair: {pair}",
        f"- User-selected Chart Timeframe: {timeframe}",
        f"- User-selected Target Trade Duration (Expiry): {expiry}",
        f"- Selected Strategy Profile: {strategy}",
    ]
    if user_note:
        lines.append(f"- Trader Context Note: {user_note}")
    lines.append(
        "Remember: Never invent prices or invisible indicators. Verify whether the pair/timeframe on the screenshot matches the selected settings. Return strictly valid JSON with overall_verdict ('ACTIONABLE' or 'NO TRADE'), full technical_breakdown, and EXACTLY TWO predictions."
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Multi-Provider AI Vision HTTP Clients (Pure Python urllib + TLS)
# ---------------------------------------------------------------------------

def _https_json_request(
    url: str,
    method: str = "POST",
    headers: dict[str, str] | None = None,
    payload: dict[str, Any] | None = None,
    timeout: int = 75,
) -> dict[str, Any]:
    req_headers = {"Accept": "application/json", "User-Agent": "SmartTradeAI/1.0"}
    if headers:
        req_headers.update(headers)
    body = None
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        req_headers["Content-Type"] = "application/json; charset=utf-8"

    req = urllib.request.Request(url, data=body, headers=req_headers, method=method)
    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as exc:
        err_body = ""
        try:
            err_body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        detail = err_body
        try:
            parsed = json.loads(err_body)
            if isinstance(parsed, dict):
                err_obj = parsed.get("error")
                if isinstance(err_obj, dict) and err_obj.get("message"):
                    detail = str(err_obj["message"])
                elif isinstance(err_obj, str):
                    detail = err_obj
        except Exception:
            pass
        raise RuntimeError(f"HTTP {exc.code}: {detail[:400] or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error contacting AI Vision service: {exc.reason}") from exc


def _discover_gemini_vision_models(api_key: str) -> list[str]:
    now = time.time()
    cache_key = hashlib.sha256(api_key.encode("utf-8")).hexdigest()[:16]
    with _lock:
        cached = _gemini_model_cache.get(cache_key)
        if cached and (now - cached[0]) < 3600:
            return list(cached[1])

    preferred_order = [
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-3-flash-preview",
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-flash-latest",
    ]
    discovered: list[str] = []
    try:
        url = f"https://generativelanguage.googleapis.com/v1beta/models?key={urllib.parse.quote(api_key)}"
        resp = _https_json_request(url, method="GET", timeout=15)
        available = set()
        for item in resp.get("models", []) or []:
            methods = item.get("supportedGenerationMethods") or []
            name = str(item.get("name", ""))
            if "generateContent" in methods and name.startswith("models/"):
                short = name.split("/", 1)[1]
                if not any(skip in short for skip in ("tts", "image-generation", "embedding", "imagen", "veo", "audio")):
                    available.add(short)
        for cand in preferred_order:
            if cand in available:
                discovered.append(cand)
        # Also include newest flash models published in the account
        flash_extras = sorted(
            [m for m in available if "flash" in m and m not in discovered],
            reverse=True,
        )
        discovered.extend(flash_extras[:4])
    except Exception:
        pass

    if not discovered:
        discovered = preferred_order

    with _lock:
        _gemini_model_cache[cache_key] = (now, discovered)
    return discovered


def _call_gemini_vision(
    api_key: str,
    image_b64: str,
    image_mime: str,
    user_prompt: str,
    custom_model: str = "",
) -> tuple[str, str]:
    models = [custom_model] if custom_model else _discover_gemini_vision_models(api_key)
    last_err = "No Gemini vision model available."

    for model in models:
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{urllib.parse.quote(model)}:generateContent?key={urllib.parse.quote(api_key)}"
        )
        payload = {
            "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
            "contents": [
                {
                    "role": "user",
                    "parts": [
                        {"inlineData": {"mimeType": image_mime, "data": image_b64}},
                        {"text": user_prompt},
                    ],
                }
            ],
            "generationConfig": {
                "temperature": 0.15,
                "responseMimeType": "application/json",
            },
        }
        try:
            resp = _https_json_request(url, method="POST", payload=payload, timeout=80)
            candidates = resp.get("candidates") or []
            if not candidates:
                block_reason = (resp.get("promptFeedback") or {}).get("blockReason", "Empty response")
                raise RuntimeError(f"Gemini returned no candidates ({block_reason}).")
            parts = ((candidates[0].get("content") or {}).get("parts")) or []
            texts = [str(p.get("text", "")) for p in parts if "text" in p and not p.get("thought")]
            if not texts:
                texts = [str(p.get("text", "")) for p in parts if "text" in p]
            combined = "\n".join(texts).strip()
            if combined:
                return (combined, model)
        except Exception as exc:
            last_err = str(exc)
            # Auth / quota errors on invalid key shouldn't loop 6 times if key is invalid
            if "API_KEY_INVALID" in last_err or "API key not valid" in last_err:
                raise RuntimeError("Your Gemini API key is not valid. Please double-check it in AI Settings.") from exc
            continue

    raise RuntimeError(f"Gemini Vision request failed: {last_err}")


def _call_openai_compatible_vision(
    provider: str,
    api_key: str,
    image_b64: str,
    image_mime: str,
    user_prompt: str,
    custom_model: str = "",
) -> tuple[str, str]:
    if provider == "groq":
        endpoint = "https://api.groq.com/openai/v1/chat/completions"
        models = [custom_model] if custom_model else [
            "meta-llama/llama-4-scout-17b-16e-instruct",
        ]
    elif provider == "openrouter":
        endpoint = "https://openrouter.ai/api/v1/chat/completions"
        models = [custom_model] if custom_model else [
            "google/gemini-2.5-flash",
            "openai/gpt-4o-mini",
        ]
    else:
        endpoint = "https://api.openai.com/v1/chat/completions"
        models = [custom_model] if custom_model else [
            "gpt-4o",
            "gpt-4.1-mini",
            "gpt-4o-mini",
        ]

    data_uri = f"data:{image_mime};base64,{image_b64}"
    headers = {"Authorization": f"Bearer {api_key}"}
    if provider == "openrouter":
        headers["HTTP-Referer"] = "https://smarttrade-ai.local"
        headers["X-Title"] = "SmartTrade AI"

    last_err = f"{provider} vision call failed."
    for model in models:
        payload: dict[str, Any] = {
            "model": model,
            "temperature": 0.15,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": user_prompt},
                        {"type": "image_url", "image_url": {"url": data_uri, "detail": "high"}},
                    ],
                },
            ],
        }
        try:
            resp = _https_json_request(endpoint, method="POST", headers=headers, payload=payload, timeout=80)
            choices = resp.get("choices") or []
            if not choices:
                raise RuntimeError("Model returned empty choices.")
            content = ((choices[0].get("message") or {}).get("content")) or ""
            if isinstance(content, list):
                content = "\n".join(str(item.get("text", "")) for item in content if isinstance(item, dict))
            content = str(content).strip()
            if content:
                return (content, model)
        except Exception as exc:
            last_err = str(exc)
            if "401" in last_err or "Incorrect API key" in last_err or "Invalid API Key" in last_err:
                raise RuntimeError(f"Authentication failed for {provider.upper()} API key. Please check your key in AI Settings.") from exc
            continue

    raise RuntimeError(f"{provider.upper()} Vision request failed: {last_err}")


def extract_json_object(raw_text: str) -> dict[str, Any]:
    text = raw_text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        snippet = text[start:end + 1]
        obj = json.loads(snippet)
        if isinstance(obj, dict):
            return obj
    raise ValueError("AI Vision model returned malformed JSON. Please retry the analysis.")


def normalize_analysis_result(raw: dict[str, Any], default_expiry: str, strategy: str) -> dict[str, Any]:
    is_valid_chart = bool(raw.get("is_valid_chart", True))
    verdict = str(raw.get("overall_verdict", "NO TRADE")).strip().upper()
    if verdict not in {"ACTIONABLE", "NO TRADE"}:
        verdict = "NO TRADE"
    if not is_valid_chart:
        verdict = "NO TRADE"

    meta_in = raw.get("chart_metadata") if isinstance(raw.get("chart_metadata"), dict) else {}
    chart_metadata = {
        "detected_pair": str(meta_in.get("detected_pair") or "Not legible").strip()[:80],
        "detected_timeframe": str(meta_in.get("detected_timeframe") or "Not legible").strip()[:40],
        "visible_current_price": str(meta_in.get("visible_current_price") or "Not legible").strip()[:50],
        "chart_clarity": str(meta_in.get("chart_clarity") or "Medium").strip()[:20],
        "mismatch_warning": str(meta_in.get("mismatch_warning") or "").strip()[:300],
    }

    tb_in = raw.get("technical_breakdown") if isinstance(raw.get("technical_breakdown"), dict) else {}
    trend_in = tb_in.get("trend") if isinstance(tb_in.get("trend"), dict) else {}
    sr_in = tb_in.get("support_resistance") if isinstance(tb_in.get("support_resistance"), dict) else {}
    mom_in = tb_in.get("momentum") if isinstance(tb_in.get("momentum"), dict) else {}

    patterns_out = []
    for item in (tb_in.get("candlestick_patterns") or [])[:6]:
        if isinstance(item, dict):
            patterns_out.append({
                "name": str(item.get("name") or "Price Action Observation").strip()[:90],
                "location": str(item.get("location") or "Recent candles").strip()[:100],
                "implication": str(item.get("implication") or "Neutral").strip()[:40],
                "detail": str(item.get("detail") or "").strip()[:260],
            })
        elif isinstance(item, str) and item.strip():
            patterns_out.append({
                "name": item.strip()[:90],
                "location": "Visible chart",
                "implication": "Neutral",
                "detail": "",
            })

    indicators = [
        str(x).strip()[:180]
        for x in (tb_in.get("indicators_observed") or [])
        if str(x).strip()
    ][:8]
    if not indicators:
        indicators = ["None visible on chart (pure price-action chart)"]

    risk_factors = [
        str(x).strip()[:220]
        for x in (tb_in.get("risk_factors") or [])
        if str(x).strip()
    ][:6]

    technical_breakdown = {
        "trend": {
            "primary_bias": str(trend_in.get("primary_bias") or "Unclear").strip()[:50],
            "structure_detail": str(trend_in.get("structure_detail") or "No clear swing structure confirmed.").strip()[:450],
        },
        "candlestick_patterns": patterns_out,
        "support_resistance": {
            "resistance_levels": [str(x).strip()[:160] for x in (sr_in.get("resistance_levels") or []) if str(x).strip()][:5],
            "support_levels": [str(x).strip()[:160] for x in (sr_in.get("support_levels") or []) if str(x).strip()][:5],
            "price_position": str(sr_in.get("price_position") or "See chart structure summary.").strip()[:280],
        },
        "momentum": {
            "state": str(mom_in.get("state") or "Unclear").strip()[:60],
            "detail": str(mom_in.get("detail") or "No clear momentum dominance observed.").strip()[:360],
        },
        "indicators_observed": indicators,
        "risk_factors": risk_factors,
    }

    preds_in = raw.get("predictions") if isinstance(raw.get("predictions"), list) else []
    preds_out: list[dict[str, Any]] = []
    for idx in range(2):
        p = preds_in[idx] if idx < len(preds_in) and isinstance(preds_in[idx], dict) else {}
        direction = str(p.get("direction") or "NO TRADE").strip().upper()
        if "CALL" in direction or "BUY" in direction:
            direction = "CALL"
        elif "PUT" in direction or "SELL" in direction:
            direction = "PUT"
        else:
            direction = "NO TRADE"

        if not is_valid_chart:
            direction = "NO TRADE"

        try:
            conf = int(round(float(p.get("confidence", 0))))
        except (TypeError, ValueError):
            conf = 0
        conf = max(0, min(100, conf))
        if direction == "NO TRADE":
            conf = 0

        status = str(p.get("status") or "").strip().upper()
        if status not in {"ACTIVE SETUP", "WAIT FOR TRIGGER", "DO NOT ENTER"}:
            if direction == "NO TRADE":
                status = "DO NOT ENTER"
            elif verdict == "NO TRADE":
                status = "WAIT FOR TRIGGER"
            else:
                status = "ACTIVE SETUP" if idx == 0 else "WAIT FOR TRIGGER"

        if verdict == "NO TRADE" and status == "ACTIVE SETUP":
            status = "WAIT FOR TRIGGER" if is_valid_chart else "DO NOT ENTER"

        default_label = "Primary Prediction" if idx == 0 else "Secondary / Conditional Prediction"
        preds_out.append({
            "slot": idx + 1,
            "label": str(p.get("label") or default_label).strip()[:70],
            "direction": direction,
            "status": status,
            "confidence": conf,
            "entry_condition": str(
                p.get("entry_condition")
                or ("No valid trade setup — stand aside." if not is_valid_chart else "Wait for clean candle close confirmation.")
            ).strip()[:320],
            "recommended_expiry": str(p.get("recommended_expiry") or default_expiry).strip()[:60],
            "explanation": str(
                p.get("explanation")
                or "Insufficient visual confirmation to justify an entry."
            ).strip()[:520],
        })

    # Conservative discipline check: if primary confidence < 60% in Conservative mode, enforce NO TRADE banner
    if strategy == "Conservative" and preds_out[0]["confidence"] < 60:
        verdict = "NO TRADE"
        if preds_out[0]["status"] == "ACTIVE SETUP":
            preds_out[0]["status"] = "WAIT FOR TRIGGER"

    no_trade_reason = str(raw.get("no_trade_reason") or "").strip()[:450]
    if verdict == "NO TRADE" and not no_trade_reason:
        if not is_valid_chart:
            no_trade_reason = "The uploaded image does not appear to be a clear, readable forex candlestick chart."
        else:
            no_trade_reason = (
                "Current market conditions lack high-probability confluence under your selected strategy. "
                "Stand aside until one of the conditional triggers below is cleanly confirmed."
            )
    elif verdict == "ACTIONABLE":
        no_trade_reason = ""

    market_summary = str(raw.get("market_summary") or "").strip()[:700]
    if not market_summary:
        market_summary = no_trade_reason or "Technical evaluation completed based on visible chart structure."

    return {
        "is_valid_chart": is_valid_chart,
        "overall_verdict": verdict,
        "no_trade_reason": no_trade_reason,
        "market_summary": market_summary,
        "chart_metadata": chart_metadata,
        "technical_breakdown": technical_breakdown,
        "predictions": preds_out,
    }


def run_chart_vision_analysis(
    image_bytes: bytes,
    image_mime: str,
    pair: str,
    timeframe: str,
    expiry: str,
    strategy: str,
    user_note: str,
) -> tuple[dict[str, Any], str, str]:
    creds = get_active_ai_credentials()
    if not creds["configured"] or not creds["api_key"]:
        raise RuntimeError(
            "AI_KEY_MISSING: Connect an AI Vision API key first (for example, a free Google Gemini API key) in AI Settings."
        )

    provider = creds["provider"]
    api_key = creds["api_key"]
    custom_model = creds["custom_model"]
    image_b64 = base64.b64encode(image_bytes).decode("ascii")
    user_prompt = build_user_prompt(pair, timeframe, expiry, strategy, user_note)

    if provider == "gemini":
        raw_text, model_used = _call_gemini_vision(api_key, image_b64, image_mime, user_prompt, custom_model)
    else:
        raw_text, model_used = _call_openai_compatible_vision(
            provider, api_key, image_b64, image_mime, user_prompt, custom_model
        )

    parsed = extract_json_object(raw_text)
    normalized = normalize_analysis_result(parsed, expiry, strategy)
    return (normalized, provider, model_used)


def verify_api_key_live(provider: str, api_key: str, custom_model: str = "") -> tuple[bool, str]:
    """Perform a lightweight live API handshake to verify the key works."""
    if provider == "gemini":
        url = f"https://generativelanguage.googleapis.com/v1beta/models?key={urllib.parse.quote(api_key)}"
        resp = _https_json_request(url, method="GET", timeout=15)
        models = resp.get("models") or []
        if not models:
            raise RuntimeError("Connected, but no Gemini models were listed for this key.")
        chosen = custom_model or _discover_gemini_vision_models(api_key)[0]
        return (True, f"Verified Google Gemini Vision ({chosen})")

    if provider == "groq":
        resp = _https_json_request(
            "https://api.groq.com/openai/v1/models",
            method="GET",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15,
        )
        if not resp.get("data"):
            raise RuntimeError("No Groq models returned.")
        return (True, f"Verified Groq Vision ({custom_model or 'llama-4-scout-17b-16e-instruct'})")

    if provider == "openrouter":
        resp = _https_json_request(
            "https://openrouter.ai/api/v1/auth/key",
            method="GET",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15,
        )
        if not isinstance(resp, dict):
            raise RuntimeError("Unexpected OpenRouter response.")
        return (True, f"Verified OpenRouter Vision ({custom_model or 'google/gemini-2.5-flash'})")

    resp = _https_json_request(
        "https://api.openai.com/v1/models",
        method="GET",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=15,
    )
    if not resp.get("data"):
        raise RuntimeError("No OpenAI models returned.")
    return (True, f"Verified OpenAI Vision ({custom_model or 'gpt-4o'})")


# ---------------------------------------------------------------------------
# HTTP Request Handler
# ---------------------------------------------------------------------------

def serialize_row(row: sqlite3.Row, include_full: bool = True) -> dict[str, Any]:
    parsed_analysis = json.loads(row["analysis_json"])
    base = {
        "id": row["id"],
        "created_at": row["created_at"],
        "currency_pair": row["currency_pair"],
        "detected_pair": row["detected_pair"],
        "timeframe": row["timeframe"],
        "trade_duration": row["trade_duration"],
        "strategy": row["strategy"],
        "user_note": row["user_note"] or "",
        "image_url": f"/api/uploads/{urllib.parse.quote(row['image_filename'])}",
        "image_width": row["image_width"],
        "image_height": row["image_height"],
        "provider_used": row["provider_used"],
        "model_used": row["model_used"],
        "overall_verdict": row["overall_verdict"],
        "no_trade_reason": row["no_trade_reason"] or "",
        "market_summary": row["market_summary"],
        "is_saved": bool(row["is_saved"]),
        "outcome": row["outcome"],
        "trader_note": row["trader_note"] or "",
        "predictions": parsed_analysis.get("predictions", []),
    }
    if include_full:
        base["analysis"] = parsed_analysis
    return base


class SmartTradeHandler(BaseHTTPRequestHandler):
    server_version = "SmartTradeAI/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {fmt % args}")

    def add_security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "camera=(self), microphone=(), geolocation=()")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; connect-src 'self'; frame-ancestors *; base-uri 'self'; object-src 'none'",
        )

    def send_json(self, status: int, payload: dict[str, Any], extra_headers: dict[str, str] | None = None) -> None:
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.add_security_headers()
        self.end_headers()
        self.wfile.write(raw)

    def send_static_file(self, file_path: Path, cache: str = "no-cache") -> None:
        if not file_path.is_file():
            self.send_json(404, {"error": "File not found."})
            return
        mime, _ = mimetypes.guess_type(str(file_path))
        content = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mime or "application/octet-stream")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", cache)
        self.add_security_headers()
        self.end_headers()
        self.wfile.write(content)

    def read_json_body(self, max_bytes: int = MAX_UPLOAD_BYTES * 2) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid Content-Length header.") from exc
        if length <= 0:
            return {}
        if length > max_bytes:
            raise ValueError("Payload exceeds maximum allowed size (12 MB image limit).")
        raw = self.rfile.read(length)
        try:
            obj = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise ValueError("Invalid JSON request body.") from exc
        if not isinstance(obj, dict):
            raise ValueError("Expected JSON object.")
        return obj

    def is_authorized(self) -> bool:
        if not ACCESS_PASSCODE:
            return True
        cookie_hdr = self.headers.get("Cookie", "")
        cookie = SimpleCookie()
        try:
            cookie.load(cookie_hdr)
        except Exception:
            return False
        morsel = cookie.get("st_auth")
        if not morsel:
            return False
        token = morsel.value
        now = time.time()
        with _lock:
            exp = _sessions.get(token, 0)
            if exp > now:
                return True
            _sessions.pop(token, None)
        return False

    def do_HEAD(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in {"/", "/health"}:
            self.send_response(200)
            self.send_header("Content-Length", "0")
            self.add_security_headers()
            self.end_headers()
            return
        self.send_response(404)
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/health":
            return self.send_json(200, {"status": "ok", "service": "SmartTrade AI"})

        if path == "/":
            return self.send_static_file(STATIC_DIR / "index.html")

        if path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return

        if path.startswith("/static/"):
            rel = path[len("/static/"):]
            target = (STATIC_DIR / rel).resolve()
            if not str(target).startswith(str(STATIC_DIR.resolve())):
                return self.send_json(403, {"error": "Forbidden."})
            return self.send_static_file(target)

        if path == "/api/status":
            creds = get_active_ai_credentials()
            with db_conn() as conn:
                total_count = conn.execute("SELECT COUNT(*) FROM analyses").fetchone()[0]
                saved_count = conn.execute("SELECT COUNT(*) FROM analyses WHERE is_saved = 1").fetchone()[0]
            return self.send_json(
                200,
                {
                    "app": "SmartTrade AI",
                    "passcode_required": bool(ACCESS_PASSCODE),
                    "authorized": self.is_authorized(),
                    "ai_configured": creds["configured"],
                    "ai_provider": creds["provider"],
                    "ai_source": creds["source"],
                    "ai_masked_key": creds["masked_key"],
                    "ai_custom_model": creds["custom_model"],
                    "defaults": {
                        "currency_pair": "EUR/USD",
                        "timeframe": "5m",
                        "trade_duration": "5m",
                        "strategy": "Conservative",
                    },
                    "options": {
                        "pairs": ALLOWED_PAIRS,
                        "timeframes": ALLOWED_TIMEFRAMES,
                        "expiries": ALLOWED_EXPIRIES,
                        "strategies": ALLOWED_STRATEGIES,
                    },
                    "stats": {
                        "total_analyses": total_count,
                        "saved_predictions": saved_count,
                    },
                },
            )

        if not self.is_authorized():
            return self.send_json(401, {"error": "Passcode required."})

        if path.startswith("/api/uploads/"):
            fname = urllib.parse.unquote(path[len("/api/uploads/"):])
            if not re.fullmatch(r"[A-Za-z0-9._-]+", fname):
                return self.send_json(400, {"error": "Invalid image filename."})
            target = (UPLOADS_DIR / fname).resolve()
            if not str(target).startswith(str(UPLOADS_DIR.resolve())):
                return self.send_json(403, {"error": "Forbidden."})
            return self.send_static_file(target, cache="private, max-age=86400")

        if path == "/api/history":
            qs = urllib.parse.parse_qs(parsed.query)
            saved_only = (qs.get("saved") or ["0"])[0] == "1"
            verdict_filter = (qs.get("filter") or ["all"])[0].lower()

            clauses = []
            params: list[Any] = []
            if saved_only:
                clauses.append("is_saved = 1")
            if verdict_filter == "no_trade":
                clauses.append("overall_verdict = 'NO TRADE'")
            elif verdict_filter == "actionable":
                clauses.append("overall_verdict = 'ACTIONABLE'")

            where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
            with db_conn() as conn:
                rows = conn.execute(
                    f"SELECT * FROM analyses {where_sql} ORDER BY created_at DESC LIMIT 100",
                    params,
                ).fetchall()
            items = [serialize_row(r, include_full=True) for r in rows]
            if verdict_filter in {"call", "put"}:
                want = verdict_filter.upper()
                items = [
                    it for it in items
                    if it.get("predictions") and it["predictions"][0].get("direction") == want
                ]
            return self.send_json(200, {"items": items})

        if path.startswith("/api/history/"):
            item_id = urllib.parse.unquote(path[len("/api/history/"):])
            with db_conn() as conn:
                row = conn.execute("SELECT * FROM analyses WHERE id = ?", (item_id,)).fetchone()
            if not row:
                return self.send_json(404, {"error": "Analysis record not found."})
            return self.send_json(200, {"item": serialize_row(row, include_full=True)})

        return self.send_json(404, {"error": "Endpoint not found."})

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/unlock":
            try:
                body = self.read_json_body(4096)
            except ValueError as exc:
                return self.send_json(400, {"error": str(exc)})
            code = str(body.get("passcode", "")).strip()
            if ACCESS_PASSCODE and hmac.compare_digest(code, ACCESS_PASSCODE):
                tok = secrets.token_urlsafe(32)
                with _lock:
                    _sessions[tok] = time.time() + 86400 * 14
                forwarded_https = self.headers.get("X-Forwarded-Proto", "").lower() == "https"
                sec = "; Secure" if forwarded_https else ""
                cookie = f"st_auth={tok}; Path=/; Max-Age=1209600; HttpOnly; SameSite=Strict{sec}"
                return self.send_json(200, {"authorized": True}, {"Set-Cookie": cookie})
            return self.send_json(401, {"error": "Incorrect passcode."})

        if not self.is_authorized():
            return self.send_json(401, {"error": "Passcode required."})

        if path == "/api/settings/key":
            try:
                body = self.read_json_body(16384)
            except ValueError as exc:
                return self.send_json(400, {"error": str(exc)})

            action = str(body.get("action", "save")).strip().lower()
            if action == "clear":
                _write_stored_secrets({})
                creds = get_active_ai_credentials()
                return self.send_json(
                    200,
                    {
                        "ok": True,
                        "message": "Saved vault key cleared.",
                        "ai_configured": creds["configured"],
                        "ai_provider": creds["provider"],
                        "ai_source": creds["source"],
                        "ai_masked_key": creds["masked_key"],
                    },
                )

            api_key = str(body.get("api_key", "")).strip()
            if not api_key or len(api_key) < 12:
                return self.send_json(400, {"error": "Please paste a valid AI Vision API key."})

            provider = str(body.get("provider", "auto")).strip().lower()
            if provider in {"", "auto"}:
                provider = detect_provider_from_key(api_key)
            if provider not in {"gemini", "groq", "openai", "openrouter"}:
                return self.send_json(400, {"error": "Unsupported AI provider selected."})

            custom_model = str(body.get("custom_model", "")).strip()[:100]

            try:
                _, verify_msg = verify_api_key_live(provider, api_key, custom_model)
            except Exception as exc:
                return self.send_json(400, {"error": f"Key verification failed: {exc}"})

            _write_stored_secrets(
                {
                    "provider": provider,
                    "api_key": api_key,
                    "custom_model": custom_model,
                    "updated_at": utc_now(),
                }
            )
            creds = get_active_ai_credentials()
            return self.send_json(
                200,
                {
                    "ok": True,
                    "message": verify_msg,
                    "ai_configured": creds["configured"],
                    "ai_provider": creds["provider"],
                    "ai_source": creds["source"],
                    "ai_masked_key": creds["masked_key"],
                },
            )

        if path == "/api/analyze":
            try:
                body = self.read_json_body()
            except ValueError as exc:
                return self.send_json(400, {"error": str(exc)})

            raw_b64 = str(body.get("image_base64", "")).strip()
            if not raw_b64:
                return self.send_json(400, {"error": "Please upload a PNG or JPG chart screenshot first."})

            if "," in raw_b64 and raw_b64.startswith("data:"):
                raw_b64 = raw_b64.split(",", 1)[1]

            try:
                image_bytes = base64.b64decode(raw_b64, validate=True)
            except Exception:
                return self.send_json(400, {"error": "Uploaded image encoding could not be decoded."})

            if len(image_bytes) > MAX_UPLOAD_BYTES:
                return self.send_json(400, {"error": "Screenshot exceeds the 12 MB size limit."})

            try:
                image_mime, width, height = inspect_image_bytes(image_bytes)
            except ValueError as exc:
                return self.send_json(400, {"error": str(exc)})

            if width < 140 or height < 140:
                return self.send_json(
                    400,
                    {"error": f"Image resolution ({width}x{height}px) is too small to inspect candlesticks accurately."},
                )

            pair = str(body.get("currency_pair") or "EUR/USD").strip()[:32] or "EUR/USD"
            timeframe = str(body.get("timeframe") or "5m").strip()[:16] or "5m"
            trade_duration = str(body.get("trade_duration") or "5m").strip()[:16] or "5m"
            strategy = str(body.get("strategy") or "Conservative").strip()
            if strategy not in ALLOWED_STRATEGIES:
                strategy = "Conservative"
            user_note = str(body.get("user_note") or "").strip()[:300]

            try:
                analysis, provider_used, model_used = run_chart_vision_analysis(
                    image_bytes=image_bytes,
                    image_mime=image_mime,
                    pair=pair,
                    timeframe=timeframe,
                    expiry=trade_duration,
                    strategy=strategy,
                    user_note=user_note,
                )
            except RuntimeError as exc:
                msg = str(exc)
                code = 428 if msg.startswith("AI_KEY_MISSING:") else 502
                return self.send_json(code, {"error": msg.replace("AI_KEY_MISSING: ", "")})
            except Exception as exc:
                return self.send_json(502, {"error": f"Analysis failed: {exc}"})

            ensure_dirs()
            analysis_id = new_id("ST")
            ext = "png" if image_mime == "image/png" else "jpg"
            image_filename = f"{analysis_id}.{ext}"
            img_path = UPLOADS_DIR / image_filename
            img_path.write_bytes(image_bytes)
            try:
                os.chmod(img_path, 0o600)
            except OSError:
                pass

            created_at = utc_now()
            detected_pair = (analysis.get("chart_metadata") or {}).get("detected_pair", "")

            with db_conn() as conn:
                conn.execute(
                    """
                    INSERT INTO analyses (
                        id, created_at, currency_pair, detected_pair, timeframe,
                        trade_duration, strategy, user_note, image_filename, image_mime,
                        image_width, image_height, provider_used, model_used,
                        overall_verdict, no_trade_reason, market_summary, analysis_json,
                        is_saved, outcome, trader_note
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'pending', '')
                    """,
                    (
                        analysis_id,
                        created_at,
                        pair,
                        detected_pair,
                        timeframe,
                        trade_duration,
                        strategy,
                        user_note,
                        image_filename,
                        image_mime,
                        width,
                        height,
                        provider_used,
                        model_used,
                        analysis["overall_verdict"],
                        analysis["no_trade_reason"],
                        analysis["market_summary"],
                        json.dumps(analysis),
                    ),
                )
                row = conn.execute("SELECT * FROM analyses WHERE id = ?", (analysis_id,)).fetchone()

            return self.send_json(200, {"item": serialize_row(row, include_full=True)})

        if path.startswith("/api/history/") and path.endswith("/update"):
            item_id = urllib.parse.unquote(path[len("/api/history/"):-len("/update")]).strip("/")
            try:
                body = self.read_json_body(8192)
            except ValueError as exc:
                return self.send_json(400, {"error": str(exc)})

            with db_conn() as conn:
                row = conn.execute("SELECT * FROM analyses WHERE id = ?", (item_id,)).fetchone()
                if not row:
                    return self.send_json(404, {"error": "Record not found."})

                is_saved = int(bool(body["is_saved"])) if "is_saved" in body else row["is_saved"]
                outcome = str(body.get("outcome", row["outcome"])).strip().lower()
                if outcome not in {"pending", "won", "lost", "skipped"}:
                    outcome = row["outcome"]
                trader_note = (
                    str(body["trader_note"]).strip()[:500]
                    if "trader_note" in body
                    else row["trader_note"]
                )
                conn.execute(
                    "UPDATE analyses SET is_saved = ?, outcome = ?, trader_note = ? WHERE id = ?",
                    (is_saved, outcome, trader_note, item_id),
                )
                updated = conn.execute("SELECT * FROM analyses WHERE id = ?", (item_id,)).fetchone()

            return self.send_json(200, {"item": serialize_row(updated, include_full=True)})

        return self.send_json(404, {"error": "Endpoint not found."})

    def do_DELETE(self) -> None:
        if not self.is_authorized():
            return self.send_json(401, {"error": "Passcode required."})

        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/history/"):
            item_id = urllib.parse.unquote(path[len("/api/history/"):]).strip("/")
            with db_conn() as conn:
                row = conn.execute("SELECT image_filename FROM analyses WHERE id = ?", (item_id,)).fetchone()
                if not row:
                    return self.send_json(404, {"error": "Record not found."})
                conn.execute("DELETE FROM analyses WHERE id = ?", (item_id,))
            try:
                img_file = UPLOADS_DIR / row["image_filename"]
                if img_file.is_file():
                    img_file.unlink()
            except OSError:
                pass
            return self.send_json(200, {"deleted": item_id})

        return self.send_json(404, {"error": "Endpoint not found."})


def main() -> None:
    parser = argparse.ArgumentParser(description="SmartTrade AI chart analysis server.")
    parser.add_argument("--host", default=os.getenv("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "8000")))
    args = parser.parse_args()

    init_db()
    creds = get_active_ai_credentials()
    server = ThreadingHTTPServer((args.host, args.port), SmartTradeHandler)
    server.daemon_threads = True
    print(
        f"SmartTrade AI listening on http://{args.host}:{args.port} "
        f"| ai_configured={creds['configured']} ({creds['provider'] or 'none'})"
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
