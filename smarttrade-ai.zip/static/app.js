(() => {
  "use strict";

  const state = {
    aiConfigured: false,
    aiProvider: null,
    aiSource: null,
    aiMaskedKey: null,
    uploadedDataUrl: "",
    uploadedMeta: "",
    currentReport: null,
    activeTab: "analyse",
    historyFilter: "all",
    historyItems: [],
    savedItems: [],
  };

  const $ = (id) => document.getElementById(id);

  // ---------------- Toast & Helpers ----------------

  let toastTimer = null;
  function showToast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add("hidden"), 3000);
  }

  function formatTimestamp(iso) {
    if (!iso) return "";
    try {
      const d = new Date(iso);
      return d.toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return iso;
    }
  }

  function biasClass(text) {
    const t = String(text || "").toLowerCase();
    if (t.includes("bull") || t.includes("up")) return "bias-bull";
    if (t.includes("bear") || t.includes("down")) return "bias-bear";
    return "bias-neutral";
  }

  async function apiFetch(url, options = {}) {
    const opts = {
      headers: { Accept: "application/json", ...(options.headers || {}) },
      ...options,
    };
    if (opts.body && typeof opts.body === "object" && !(opts.body instanceof FormData)) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(opts.body);
    }
    const resp = await fetch(url, opts);
    let data = {};
    try {
      data = await resp.json();
    } catch {
      data = {};
    }
    if (!resp.ok) {
      const err = new Error(data.error || `Request failed (${resp.status})`);
      err.status = resp.status;
      throw err;
    }
    return data;
  }

  // ---------------- Status & AI Key Modal ----------------

  async function refreshStatus() {
    try {
      const data = await apiFetch("/api/status");
      if (data.passcode_required && !data.authorized) {
        $("passcodeGate").classList.remove("hidden");
        return;
      }
      $("passcodeGate").classList.add("hidden");
      applyAiStatus(data);
      $("savedCountBadge").textContent = String(data.stats?.saved_predictions ?? 0);
      $("historyCountBadge").textContent = String(data.stats?.total_analyses ?? 0);
    } catch (err) {
      console.error("Status check failed:", err);
    }
  }

  function applyAiStatus(data) {
    state.aiConfigured = Boolean(data.ai_configured);
    state.aiProvider = data.ai_provider || null;
    state.aiSource = data.ai_source || null;
    state.aiMaskedKey = data.ai_masked_key || null;

    const btn = $("aiKeyBtn");
    const label = $("aiStatusLabel");
    const banner = $("setupNoticeBanner");

    if (state.aiConfigured) {
      btn.classList.remove("ai-pill-warn");
      btn.classList.add("ai-pill-ok");
      const prov = String(state.aiProvider || "AI").toUpperCase();
      label.textContent = `Vision Ready · ${prov}`;
      banner.classList.add("hidden");
    } else {
      btn.classList.add("ai-pill-warn");
      btn.classList.remove("ai-pill-ok");
      label.textContent = "Setup AI Key";
      banner.classList.remove("hidden");
    }
    renderModalKeyStatus();
  }

  function renderModalKeyStatus() {
    const box = $("currentKeyStatusBox");
    box.innerHTML = "";
    if (state.aiConfigured) {
      const strong = document.createElement("strong");
      strong.style.color = "#34d399";
      strong.textContent = `Connected: ${String(state.aiProvider).toUpperCase()} Vision `;
      const detail = document.createElement("span");
      detail.className = "mono";
      detail.textContent = `(${state.aiMaskedKey || "hidden"} · ${
        state.aiSource === "environment" ? "Render Env Var" : "Server Vault"
      })`;
      box.appendChild(strong);
      box.appendChild(detail);
      $("clearStoredKeyBtn").classList.toggle("hidden", state.aiSource === "environment");
    } else {
      box.textContent = "Status: Not connected yet. Paste your API key below to enable genuine AI chart analysis.";
      $("clearStoredKeyBtn").classList.add("hidden");
    }
  }

  function openAiModal() {
    $("apiKeyFeedback").classList.add("hidden");
    renderModalKeyStatus();
    $("aiKeyModal").classList.remove("hidden");
    setTimeout(() => $("apiKeyInput").focus(), 60);
  }

  function closeAiModal() {
    $("aiKeyModal").classList.add("hidden");
  }

  // ---------------- Tabs Navigation ----------------

  function switchTab(tabName) {
    state.activeTab = tabName;
    document.querySelectorAll(".nav-tab").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.tab === tabName);
    });
    $("viewAnalyse").classList.toggle("active", tabName === "analyse");
    $("viewSaved").classList.toggle("active", tabName === "saved");
    $("viewHistory").classList.toggle("active", tabName === "history");

    if (tabName === "saved") loadSavedList();
    if (tabName === "history") loadHistoryList();
  }

  // ---------------- Image Selection, Compression & Validation ----------------

  async function processSelectedFile(file) {
    if (!file) return;
    const validTypes = ["image/png", "image/jpeg", "image/jpg"];
    const nameLower = (file.name || "").toLowerCase();
    const extOk = nameLower.endsWith(".png") || nameLower.endsWith(".jpg") || nameLower.endsWith(".jpeg");
    if (!validTypes.includes(file.type) && !extOk) {
      showAnalyseError("Please select a PNG, JPG, or JPEG chart screenshot.");
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      showAnalyseError("Image is larger than 12 MB. Please upload a standard chart screenshot.");
      return;
    }
    hideAnalyseError();

    const rawDataUrl = await readFileAsDataUrl(file);
    const img = await loadImageElement(rawDataUrl);

    let finalDataUrl = rawDataUrl;
    let width = img.naturalWidth;
    let height = img.naturalHeight;

    // Optimize huge mobile screenshots (> 3.5MB or > 2000px) while keeping axis digits crisp
    if (file.size > 3.5 * 1024 * 1024 || width > 2000 || height > 2000) {
      const scale = Math.min(1, 1920 / Math.max(width, height));
      width = Math.round(width * scale);
      height = Math.round(height * scale);
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);
      finalDataUrl = canvas.toDataURL("image/jpeg", 0.92);
    }

    const fmt = finalDataUrl.startsWith("data:image/png") ? "PNG" : "JPG";
    setUploadedChart(finalDataUrl, `${fmt} · ${width}×${height}px`);
  }

  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error("Could not read image file."));
      reader.readAsDataURL(file);
    });
  }

  function loadImageElement(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Invalid or corrupted image file."));
      img.src = src;
    });
  }

  function setUploadedChart(dataUrl, metaLabel) {
    state.uploadedDataUrl = dataUrl;
    state.uploadedMeta = metaLabel;
    $("uploadPreviewImg").src = dataUrl;
    $("uploadFileMeta").textContent = metaLabel;
    $("uploadEmptyState").classList.add("hidden");
    $("uploadPreviewWrap").classList.remove("hidden");
  }

  function clearUploadedChart() {
    state.uploadedDataUrl = "";
    state.uploadedMeta = "";
    $("chartFileInput").value = "";
    $("uploadPreviewImg").removeAttribute("src");
    $("uploadPreviewWrap").classList.add("hidden");
    $("uploadEmptyState").classList.remove("hidden");
  }

  // ---------------- Sample Realistic IQ Option EUR/USD 5m Chart Generator ----------------

  function generateSampleIqOptionChart() {
    const W = 1280;
    const H = 720;
    const canvas = document.createElement("canvas");
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");

    // IQ Option dark slate background
    ctx.fillStyle = "#101622";
    ctx.fillRect(0, 0, W, H);

    // Top platform bar
    ctx.fillStyle = "#171f30";
    ctx.fillRect(0, 0, W, 48);
    ctx.strokeStyle = "rgba(148,163,184,0.16)";
    ctx.beginPath();
    ctx.moveTo(0, 48);
    ctx.lineTo(W, 48);
    ctx.stroke();

    // Asset tab (EUR/USD · 5m)
    ctx.fillStyle = "#222e46";
    ctx.fillRect(18, 8, 210, 32);
    ctx.fillStyle = "#f8fafc";
    ctx.font = "bold 15px monospace";
    ctx.fillText("EUR/USD", 32, 29);
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px monospace";
    ctx.fillText("Forex · 5m Candles", 108, 29);

    // Chart area bounds
    const chartLeft = 40;
    const chartRight = 1145;
    const chartTop = 72;
    const chartBottom = 505;
    const rsiTop = 540;
    const rsiBottom = 675;

    const minP = 1.0825;
    const maxP = 1.0875;
    const priceToY = (p) =>
      chartBottom - ((p - minP) / (maxP - minP)) * (chartBottom - chartTop);

    // Horizontal grid lines & right price axis
    ctx.font = "12px monospace";
    for (let i = 0; i <= 8; i++) {
      const p = minP + ((maxP - minP) * i) / 8;
      const y = priceToY(p);
      ctx.strokeStyle = "rgba(148,163,184,0.08)";
      ctx.beginPath();
      ctx.moveTo(chartLeft, y);
      ctx.lineTo(chartRight, y);
      ctx.stroke();

      ctx.fillStyle = "#94a3b8";
      ctx.fillText(p.toFixed(5), chartRight + 12, y + 4);
    }

    // Key Support (1.08340) & Resistance (1.08660) zones
    const resY = priceToY(1.0866);
    ctx.fillStyle = "rgba(239, 68, 68, 0.08)";
    ctx.fillRect(chartLeft, resY - 8, chartRight - chartLeft, 16);
    ctx.strokeStyle = "rgba(239, 68, 68, 0.55)";
    ctx.setLineDash([6, 5]);
    ctx.beginPath();
    ctx.moveTo(chartLeft, resY);
    ctx.lineTo(chartRight, resY);
    ctx.stroke();

    const supY = priceToY(1.0834);
    ctx.fillStyle = "rgba(16, 185, 129, 0.08)";
    ctx.fillRect(chartLeft, supY - 8, chartRight - chartLeft, 16);
    ctx.strokeStyle = "rgba(16, 185, 129, 0.55)";
    ctx.beginPath();
    ctx.moveTo(chartLeft, supY);
    ctx.lineTo(chartRight, supY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Deterministic realistic EUR/USD 5m OHLC candles showing uptrend pullback to support + bullish rejection + engulfing
    const closes = [
      1.0841, 1.0844, 1.0842, 1.0847, 1.0852, 1.0856, 1.0861, 1.0865,
      1.0863, 1.0858, 1.0854, 1.0850, 1.0846, 1.0841, 1.0836, 1.0835,
      1.0839, 1.0844, 1.0849, 1.0855, 1.0860, 1.0865, 1.0862, 1.0857,
      1.0851, 1.0847, 1.0842, 1.0838, 1.0835, 1.08345, 1.08395, 1.08445,
    ];
    const candles = closes.map((c, idx) => {
      const o = idx === 0 ? 1.0839 : closes[idx - 1];
      const body = Math.abs(c - o);
      let hi = Math.max(o, c) + Math.max(body * 0.45, 0.00018);
      let lo = Math.min(o, c) - Math.max(body * 0.45, 0.00018);
      // Pin bar rejection wick right at 1.08340 support on candle 29
      if (idx === 29) {
        lo = 1.08312;
        hi = 1.08365;
      }
      // Strong bullish engulfing confirmation on candles 30-31
      if (idx === 30) {
        lo = 1.08338;
        hi = 1.08405;
      }
      if (idx === 31) {
        lo = 1.08390;
        hi = 1.08458;
      }
      return { o, h: hi, l: lo, c };
    });

    const step = (chartRight - chartLeft - 40) / candles.length;
    const candleW = Math.max(10, Math.floor(step * 0.58));

    // EMA 20 overlay
    const ema = [];
    const k = 2 / (14 + 1);
    candles.forEach((cd, i) => {
      ema.push(i === 0 ? cd.c : cd.c * k + ema[i - 1] * (1 - k));
    });
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ema.forEach((val, i) => {
      const x = chartLeft + 24 + i * step;
      const y = priceToY(val);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Draw candles
    candles.forEach((cd, i) => {
      const x = chartLeft + 24 + i * step;
      const isBull = cd.c >= cd.o;
      const color = isBull ? "#10b981" : "#ef4444";
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = 1.8;

      ctx.beginPath();
      ctx.moveTo(x, priceToY(cd.h));
      ctx.lineTo(x, priceToY(cd.l));
      ctx.stroke();

      const yTop = priceToY(Math.max(cd.o, cd.c));
      const yBot = priceToY(Math.min(cd.o, cd.c));
      const hRect = Math.max(2, yBot - yTop);
      ctx.fillRect(x - candleW / 2, yTop, candleW, hRect);
    });

    // Current price callout tag on right axis
    const lastPrice = candles[candles.length - 1].c;
    const lastY = priceToY(lastPrice);
    ctx.strokeStyle = "#10b981";
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(chartLeft, lastY);
    ctx.lineTo(chartRight, lastY);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = "#10b981";
    ctx.fillRect(chartRight + 4, lastY - 11, 86, 22);
    ctx.fillStyle = "#04130d";
    ctx.font = "bold 12px monospace";
    ctx.fillText(lastPrice.toFixed(5), chartRight + 11, lastY + 4);

    // Legend
    ctx.fillStyle = "#38bdf8";
    ctx.font = "12px monospace";
    ctx.fillText("EMA(14)", chartLeft + 8, chartTop + 14);

    // RSI(14) Sub-pane
    ctx.strokeStyle = "rgba(148,163,184,0.18)";
    ctx.strokeRect(chartLeft, rsiTop, chartRight - chartLeft, rsiBottom - rsiTop);
    ctx.fillStyle = "#94a3b8";
    ctx.font = "11px monospace";
    ctx.fillText("RSI (14) · 48.6 rebounding from 32", chartLeft + 8, rsiTop + 16);

    const rsiToY = (r) => rsiBottom - (r / 100) * (rsiBottom - rsiTop);
    [70, 30].forEach((lvl) => {
      ctx.strokeStyle = "rgba(148,163,184,0.2)";
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(chartLeft, rsiToY(lvl));
      ctx.lineTo(chartRight, rsiToY(lvl));
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillText(String(lvl), chartRight + 12, rsiToY(lvl) + 4);
    });

    const rsiVals = [
      51, 55, 53, 58, 63, 66, 69, 71,
      65, 58, 52, 47, 42, 37, 33, 31,
      39, 46, 53, 60, 64, 68, 61, 55,
      49, 44, 39, 35, 32, 31, 41, 48.6,
    ];
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    rsiVals.forEach((rv, i) => {
      const x = chartLeft + 24 + i * step;
      const y = rsiToY(rv);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    const dataUrl = canvas.toDataURL("image/png");
    setUploadedChart(dataUrl, "Sample PNG · 1280×720px");
    $("pairSelect").value = "EUR/USD";
    $("customPairInput").classList.add("hidden");
    $("timeframeSelect").value = "5m";
    $("durationSelect").value = "5m";
    hideAnalyseError();
    showToast("Sample EUR/USD 5m chart loaded");
  }

  // ---------------- Running Genuine AI Analysis ----------------

  function showAnalyseError(msg) {
    const box = $("analyseErrorBox");
    box.textContent = msg;
    box.classList.remove("hidden");
  }

  function hideAnalyseError() {
    $("analyseErrorBox").classList.add("hidden");
  }

  function getSelectedPair() {
    const val = $("pairSelect").value;
    if (val === "CUSTOM") {
      return $("customPairInput").value.trim().toUpperCase() || "EUR/USD";
    }
    return val;
  }

  async function handleRunAnalysis(evt) {
    evt.preventDefault();
    hideAnalyseError();

    if (!state.uploadedDataUrl) {
      showAnalyseError("Please upload an IQ Option chart screenshot (or load the sample chart) first.");
      return;
    }

    if (!state.aiConfigured) {
      openAiModal();
      return;
    }

    const btn = $("analyseSubmitBtn");
    const btnLabel = $("analyseBtnLabel");
    btn.disabled = true;
    btnLabel.textContent = "Analysing Screenshot via AI Vision…";

    $("resultsEmptyState").classList.add("hidden");
    $("resultsReportWrap").classList.add("hidden");
    $("resultsLoadingState").classList.remove("hidden");

    try {
      const resp = await apiFetch("/api/analyze", {
        method: "POST",
        body: {
          image_base64: state.uploadedDataUrl,
          currency_pair: getSelectedPair(),
          timeframe: $("timeframeSelect").value,
          trade_duration: $("durationSelect").value,
          strategy: $("strategySelect").value,
          user_note: $("userNoteInput").value.trim(),
        },
      });
      renderAnalysisReport(resp.item);
      await refreshStatus();
      if (window.innerWidth < 1024) {
        $("verdictBanner").scrollIntoView({ behavior: "smooth", block: "start" });
      }
    } catch (err) {
      $("resultsLoadingState").classList.add("hidden");
      if (state.currentReport) {
        $("resultsReportWrap").classList.remove("hidden");
      } else {
        $("resultsEmptyState").classList.remove("hidden");
      }
      if (err.status === 428) {
        openAiModal();
      }
      showAnalyseError(err.message || "Chart analysis failed.");
    } finally {
      btn.disabled = false;
      btnLabel.textContent = "Analyse Chart Screenshot";
    }
  }

  // ---------------- Rendering the Analysis Report ----------------

  function renderAnalysisReport(item) {
    state.currentReport = item;
    const analysis = item.analysis || {};
    const meta = analysis.chart_metadata || {};
    const tb = analysis.technical_breakdown || {};
    const preds = analysis.predictions || item.predictions || [];

    $("resultsEmptyState").classList.add("hidden");
    $("resultsLoadingState").classList.add("hidden");
    $("resultsReportWrap").classList.remove("hidden");

    const isActionable = item.overall_verdict === "ACTIONABLE";
    const banner = $("verdictBanner");
    banner.classList.toggle("is-actionable", isActionable);
    banner.classList.toggle("is-notrade", !isActionable);

    const badge = $("verdictBadge");
    badge.className = `verdict-pill ${isActionable ? "actionable" : "notrade"}`;
    badge.textContent = isActionable ? "ACTIONABLE SETUP" : "NO TRADE — STAND ASIDE";

    $("reportPairTag").textContent = `${item.currency_pair} · ${item.timeframe} → ${item.trade_duration}`;
    $("reportStrategyTag").textContent = item.strategy;
    $("marketSummaryText").textContent = item.market_summary || "";

    const ntBox = $("noTradeReasonBox");
    if (!isActionable && item.no_trade_reason) {
      $("noTradeReasonText").textContent = ` ${item.no_trade_reason}`;
      ntBox.classList.remove("hidden");
    } else {
      ntBox.classList.add("hidden");
    }

    const mmBox = $("mismatchAlertBox");
    if (meta.mismatch_warning) {
      $("mismatchAlertText").textContent = ` ${meta.mismatch_warning}`;
      mmBox.classList.remove("hidden");
    } else {
      mmBox.classList.add("hidden");
    }

    $("metaDetectedPair").textContent = meta.detected_pair || "Not legible";
    $("metaDetectedTf").textContent = meta.detected_timeframe || "Not legible";
    $("metaVisiblePrice").textContent = meta.visible_current_price || "Not legible";
    $("metaModelInfo").textContent = `${meta.chart_clarity || "—"} · ${item.model_used || item.provider_used}`;

    updateSaveButtonUI(item.is_saved);

    // Render EXACTLY TWO Predictions
    const grid = $("predictionsGrid");
    grid.innerHTML = "";
    preds.slice(0, 2).forEach((p, idx) => {
      const dir = String(p.direction || "NO TRADE").toUpperCase();
      const cls = dir === "CALL" ? "dir-call" : dir === "PUT" ? "dir-put" : "dir-notrade";
      const displayDir =
        dir === "CALL" ? "▲ CALL (BUY)" : dir === "PUT" ? "▼ PUT (SELL)" : "■ NO TRADE";
      const conf = Math.max(0, Math.min(100, Number(p.confidence) || 0));

      const card = document.createElement("article");
      card.className = `pred-card ${cls}`;

      const slotRow = document.createElement("div");
      slotRow.className = "pred-slot-row";
      const slotLbl = document.createElement("span");
      slotLbl.className = "pred-slot-label";
      slotLbl.textContent = `Prediction #${idx + 1} · ${p.label || (idx === 0 ? "Primary" : "Secondary")}`;
      const statusChip = document.createElement("span");
      statusChip.className = "pred-status-chip";
      statusChip.textContent = p.status || "SETUP";
      slotRow.append(slotLbl, statusChip);

      const mainRow = document.createElement("div");
      mainRow.className = "pred-main-row";
      const dirBadge = document.createElement("div");
      dirBadge.className = "dir-badge";
      dirBadge.textContent = displayDir;

      const confBlock = document.createElement("div");
      confBlock.className = "conf-block";
      const confNum = document.createElement("div");
      confNum.className = "conf-num";
      confNum.textContent = `${conf}%`;
      const confCap = document.createElement("span");
      confCap.className = "conf-caption";
      confCap.textContent = "Confidence";
      confBlock.append(confNum, confCap);
      mainRow.append(dirBadge, confBlock);

      const meter = document.createElement("div");
      meter.className = "conf-meter";
      const fill = document.createElement("div");
      fill.className = "conf-fill";
      fill.style.width = `${conf}%`;
      meter.appendChild(fill);

      const entryBox = makeKvBlock("Suggested Entry / Trigger Condition", p.entry_condition || "—");
      const expBox = makeKvBlock("Recommended Expiry Time", p.recommended_expiry || item.trade_duration);

      const expl = document.createElement("p");
      expl.className = "pred-explanation";
      expl.textContent = p.explanation || "";

      card.append(slotRow, mainRow, meter, entryBox, expBox, expl);
      grid.appendChild(card);
    });

    // Technical Breakdown
    const trend = tb.trend || {};
    const trendBadge = $("trendBiasBadge");
    trendBadge.textContent = trend.primary_bias || "Unclear";
    trendBadge.className = `bias-pill ${biasClass(trend.primary_bias)}`;
    $("trendDetailText").textContent = trend.structure_detail || "—";

    const mom = tb.momentum || {};
    const momBadge = $("momentumStateBadge");
    momBadge.textContent = mom.state || "Unclear";
    momBadge.className = `bias-pill ${biasClass(mom.state)}`;
    $("momentumDetailText").textContent = mom.detail || "—";

    // Candlestick patterns
    const patContainer = $("patternsList");
    patContainer.innerHTML = "";
    const patterns = tb.candlestick_patterns || [];
    if (!patterns.length) {
      const emptyP = document.createElement("p");
      emptyP.className = "tech-body";
      emptyP.textContent = "No distinct textbook reversal/continuation pattern isolated on recent candles.";
      patContainer.appendChild(emptyP);
    } else {
      patterns.forEach((pt) => {
        const box = document.createElement("div");
        box.className = "pattern-item";
        const top = document.createElement("div");
        top.className = "pattern-top";
        const nm = document.createElement("span");
        nm.className = "pattern-name";
        nm.textContent = pt.name || "Pattern";
        const imp = document.createElement("span");
        imp.className = `bias-pill ${biasClass(pt.implication)}`;
        imp.textContent = pt.implication || "Neutral";
        top.append(nm, imp);

        const loc = document.createElement("div");
        loc.className = "pattern-loc";
        loc.textContent = pt.location || "";

        const det = document.createElement("p");
        det.className = "tech-body";
        det.textContent = pt.detail || "";

        box.append(top, loc, det);
        patContainer.appendChild(box);
      });
    }

    // Support & Resistance
    const sr = tb.support_resistance || {};
    fillList($("resistanceList"), sr.resistance_levels, "No clear overhead horizontal level legible");
    fillList($("supportList"), sr.support_levels, "No clear floor support level legible");
    $("srPositionText").textContent = sr.price_position || "";

    // Indicators & Risk Factors
    fillList($("indicatorsList"), tb.indicators_observed, "None visible on chart");
    fillList($("riskFactorsList"), tb.risk_factors, "Standard short-expiry volatility risk");

    // Journal controls
    setOutcomeUI(item.outcome || "pending");
    $("traderNoteInput").value = item.trader_note || "";
  }

  function makeKvBlock(label, val) {
    const wrap = document.createElement("div");
    wrap.className = "pred-kv";
    const l = document.createElement("span");
    l.className = "pred-kv-label";
    l.textContent = label;
    const v = document.createElement("div");
    v.className = "pred-kv-val";
    v.textContent = val;
    wrap.append(l, v);
    return wrap;
  }

  function fillList(ul, arr, fallback) {
    ul.innerHTML = "";
    const items = Array.isArray(arr) && arr.length ? arr : [fallback];
    items.forEach((txt) => {
      const li = document.createElement("li");
      li.textContent = txt;
      ul.appendChild(li);
    });
  }

  function updateSaveButtonUI(saved) {
    const btn = $("toggleSaveBtn");
    btn.classList.toggle("saved-active", Boolean(saved));
    $("saveStarIcon").textContent = saved ? "★" : "☆";
    $("saveBtnText").textContent = saved ? "Saved" : "Save Prediction";
  }

  function setOutcomeUI(outcome) {
    document.querySelectorAll(".outcome-btn").forEach((b) => {
      b.classList.toggle("active", b.dataset.outcome === outcome);
    });
  }

  // ---------------- Saving, Journal & History ----------------

  async function toggleSaveCurrent() {
    if (!state.currentReport) return;
    const nextSaved = !state.currentReport.is_saved;
    try {
      const resp = await apiFetch(`/api/history/${encodeURIComponent(state.currentReport.id)}/update`, {
        method: "POST",
        body: { is_saved: nextSaved },
      });
      state.currentReport = resp.item;
      updateSaveButtonUI(resp.item.is_saved);
      await refreshStatus();
      showToast(nextSaved ? "Prediction saved to bookmarks" : "Removed from saved");
    } catch (err) {
      showToast(err.message);
    }
  }

  async function updateJournal(fields) {
    if (!state.currentReport) return;
    try {
      const resp = await apiFetch(`/api/history/${encodeURIComponent(state.currentReport.id)}/update`, {
        method: "POST",
        body: fields,
      });
      state.currentReport = resp.item;
      setOutcomeUI(resp.item.outcome);
      showToast("Journal updated");
    } catch (err) {
      showToast(err.message);
    }
  }

  async function loadSavedList() {
    try {
      const data = await apiFetch("/api/history?saved=1");
      state.savedItems = data.items || [];
      renderCardList($("savedListContainer"), state.savedItems, "No saved predictions yet. Tap 'Save Prediction' on any analysis report to bookmark it here.");
    } catch (err) {
      showToast(err.message);
    }
  }

  async function loadHistoryList() {
    try {
      const data = await apiFetch(`/api/history?filter=${encodeURIComponent(state.historyFilter)}`);
      state.historyItems = data.items || [];
      renderStatsStrip(state.historyItems);
      renderCardList($("historyListContainer"), state.historyItems, "No chart analyses recorded yet.");
    } catch (err) {
      showToast(err.message);
    }
  }

  function renderStatsStrip(items) {
    const strip = $("accuracyStatsStrip");
    strip.innerHTML = "";
    const total = items.length;
    const noTrades = items.filter((i) => i.overall_verdict === "NO TRADE").length;
    const won = items.filter((i) => i.outcome === "won").length;
    const lost = items.filter((i) => i.outcome === "lost").length;
    const decided = won + lost;
    const winRate = decided > 0 ? `${Math.round((won / decided) * 100)}%` : "—";

    const cells = [
      { num: String(total), lbl: "Analyses Shown" },
      { num: String(total - noTrades), lbl: "Actionable Setups" },
      { num: String(noTrades), lbl: "NO TRADE Filtered" },
      { num: `${winRate} (${won}W/${lost}L)`, lbl: "Logged Win Rate" },
    ];
    cells.forEach((c) => {
      const box = document.createElement("div");
      box.className = "stat-box";
      const n = document.createElement("div");
      n.className = "stat-num";
      n.textContent = c.num;
      const l = document.createElement("div");
      l.className = "stat-lbl";
      l.textContent = c.lbl;
      box.append(n, l);
      strip.appendChild(box);
    });
  }

  function renderCardList(container, items, emptyMessage) {
    container.innerHTML = "";
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "panel";
      empty.style.gridColumn = "1 / -1";
      empty.textContent = emptyMessage;
      container.appendChild(empty);
      return;
    }

    items.forEach((it) => {
      const card = document.createElement("article");
      card.className = "hist-card";

      const img = document.createElement("img");
      img.className = "hist-thumb";
      img.src = it.image_url;
      img.alt = `${it.currency_pair} chart`;
      img.loading = "lazy";

      const body = document.createElement("div");

      const top = document.createElement("div");
      top.className = "hist-top";
      const pair = document.createElement("span");
      pair.className = "hist-pair";
      pair.textContent = `${it.is_saved ? "★ " : ""}${it.currency_pair} · ${it.timeframe}`;
      const tm = document.createElement("span");
      tm.className = "hist-time";
      tm.textContent = formatTimestamp(it.created_at);
      top.append(pair, tm);

      const predsWrap = document.createElement("div");
      predsWrap.className = "hist-preds";

      const vChip = document.createElement("span");
      vChip.className = `mini-pred ${it.overall_verdict === "ACTIONABLE" ? "mini-call" : "mini-notrade"}`;
      vChip.textContent = it.overall_verdict;
      predsWrap.appendChild(vChip);

      (it.predictions || []).slice(0, 2).forEach((p, idx) => {
        const d = String(p.direction || "NO TRADE").toUpperCase();
        const c = d === "CALL" ? "mini-call" : d === "PUT" ? "mini-put" : "mini-notrade";
        const chip = document.createElement("span");
        chip.className = `mini-pred ${c}`;
        chip.textContent = `#${idx + 1} ${d} ${p.confidence}%`;
        predsWrap.appendChild(chip);
      });

      const sum = document.createElement("p");
      sum.className = "hist-summary";
      sum.textContent = it.market_summary || "";

      const actions = document.createElement("div");
      actions.className = "hist-actions";

      const openBtn = document.createElement("button");
      openBtn.type = "button";
      openBtn.className = "btn-chip";
      openBtn.textContent = "Open Full Report";
      openBtn.addEventListener("click", () => {
        setUploadedChart(it.image_url, `Stored · ${it.image_width}×${it.image_height}px`);
        renderAnalysisReport(it);
        switchTab("analyse");
        window.scrollTo({ top: 0, behavior: "smooth" });
      });

      const delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "btn-chip btn-chip-danger";
      delBtn.textContent = "Delete";
      delBtn.addEventListener("click", async () => {
        try {
          await apiFetch(`/api/history/${encodeURIComponent(it.id)}`, { method: "DELETE" });
          if (state.currentReport && state.currentReport.id === it.id) {
            state.currentReport = null;
            $("resultsReportWrap").classList.add("hidden");
            $("resultsEmptyState").classList.remove("hidden");
          }
          await refreshStatus();
          if (state.activeTab === "saved") loadSavedList();
          if (state.activeTab === "history") loadHistoryList();
          showToast("Deleted record");
        } catch (err) {
          showToast(err.message);
        }
      });

      actions.append(openBtn, delBtn);
      body.append(top, predsWrap, sum, actions);
      card.append(img, body);
      container.appendChild(card);
    });
  }

  // ---------------- Lightbox ----------------

  function openLightbox(src) {
    if (!src) return;
    $("lightboxImg").src = src;
    $("imageLightbox").classList.remove("hidden");
  }

  // ---------------- Wire Up Events ----------------

  function initEvents() {
    // Tabs
    document.querySelectorAll(".nav-tab").forEach((btn) => {
      btn.addEventListener("click", () => switchTab(btn.dataset.tab));
    });

    // Upload zone
    const dz = $("uploadDropzone");
    const fileInput = $("chartFileInput");

    dz.addEventListener("click", (e) => {
      if (e.target.closest("button")) return;
      if (!state.uploadedDataUrl) fileInput.click();
    });
    dz.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        fileInput.click();
      }
    });

    fileInput.addEventListener("change", () => {
      if (fileInput.files && fileInput.files[0]) {
        processSelectedFile(fileInput.files[0]);
      }
    });

    ["dragenter", "dragover"].forEach((ev) => {
      dz.addEventListener(ev, (e) => {
        e.preventDefault();
        dz.classList.add("drag-over");
      });
    });
    ["dragleave", "drop"].forEach((ev) => {
      dz.addEventListener(ev, (e) => {
        e.preventDefault();
        dz.classList.remove("drag-over");
      });
    });
    dz.addEventListener("drop", (e) => {
      const f = e.dataTransfer?.files?.[0];
      if (f) processSelectedFile(f);
    });

    // Global paste support
    window.addEventListener("paste", (e) => {
      const items = e.clipboardData?.items || [];
      for (const item of items) {
        if (item.type.startsWith("image/")) {
          const f = item.getAsFile();
          if (f) {
            processSelectedFile(f);
            showToast("Pasted chart image from clipboard");
            break;
          }
        }
      }
    });

    $("changeChartBtn").addEventListener("click", () => fileInput.click());
    $("clearChartBtn").addEventListener("click", clearUploadedChart);
    $("zoomChartBtn").addEventListener("click", () => openLightbox(state.uploadedDataUrl));
    $("inspectReportImageBtn").addEventListener("click", () => {
      const src = state.currentReport?.image_url || state.uploadedDataUrl;
      openLightbox(src);
    });
    $("closeLightboxBtn").addEventListener("click", () => $("imageLightbox").classList.add("hidden"));
    $("imageLightbox").addEventListener("click", (e) => {
      if (e.target === $("imageLightbox")) $("imageLightbox").classList.add("hidden");
    });

    $("loadSampleChartBtn").addEventListener("click", generateSampleIqOptionChart);

    // Custom pair toggle & reset defaults
    $("pairSelect").addEventListener("change", () => {
      const isCustom = $("pairSelect").value === "CUSTOM";
      $("customPairInput").classList.toggle("hidden", !isCustom);
      if (isCustom) $("customPairInput").focus();
    });

    $("resetDefaultsBtn").addEventListener("click", () => {
      $("pairSelect").value = "EUR/USD";
      $("customPairInput").classList.add("hidden");
      $("customPairInput").value = "";
      $("timeframeSelect").value = "5m";
      $("durationSelect").value = "5m";
      $("strategySelect").value = "Conservative";
      $("userNoteInput").value = "";
      showToast("Reset to default EUR/USD · 5m · Conservative");
    });

    $("analyseForm").addEventListener("submit", handleRunAnalysis);
    $("toggleSaveBtn").addEventListener("click", toggleSaveCurrent);

    document.querySelectorAll(".outcome-btn").forEach((btn) => {
      btn.addEventListener("click", () => updateJournal({ outcome: btn.dataset.outcome }));
    });
    $("saveJournalBtn").addEventListener("click", () => {
      updateJournal({ trader_note: $("traderNoteInput").value.trim() });
    });

    // History filters
    document.querySelectorAll(".filter-pill").forEach((btn) => {
      btn.addEventListener("click", () => {
        state.historyFilter = btn.dataset.filter;
        document.querySelectorAll(".filter-pill").forEach((b) =>
          b.classList.toggle("active", b.dataset.filter === state.historyFilter)
        );
        loadHistoryList();
      });
    });

    // AI Key Modal
    $("aiKeyBtn").addEventListener("click", openAiModal);
    $("setupBannerBtn").addEventListener("click", openAiModal);
    $("closeAiModalBtn").addEventListener("click", closeAiModal);
    $("aiKeyModal").addEventListener("click", (e) => {
      if (e.target === $("aiKeyModal")) closeAiModal();
    });

    $("saveApiKeyForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const fb = $("apiKeyFeedback");
      const btn = $("saveKeySubmitBtn");
      fb.classList.add("hidden");
      btn.disabled = true;
      btn.textContent = "Verifying Key…";
      try {
        const resp = await apiFetch("/api/settings/key", {
          method: "POST",
          body: {
            provider: $("providerSelect").value,
            api_key: $("apiKeyInput").value.trim(),
          },
        });
        $("apiKeyInput").value = "";
        applyAiStatus(resp);
        fb.style.color = "#34d399";
        fb.textContent = resp.message || "Key verified & saved!";
        fb.classList.remove("hidden");
        showToast("AI Vision key connected!");
        setTimeout(closeAiModal, 900);
      } catch (err) {
        fb.style.color = "#f87171";
        fb.textContent = err.message;
        fb.classList.remove("hidden");
      } finally {
        btn.disabled = false;
        btn.textContent = "Verify & Save Key";
      }
    });

    $("clearStoredKeyBtn").addEventListener("click", async () => {
      try {
        const resp = await apiFetch("/api/settings/key", {
          method: "POST",
          body: { action: "clear" },
        });
        applyAiStatus(resp);
        showToast("Cleared saved API key");
      } catch (err) {
        showToast(err.message);
      }
    });

    // Optional passcode form
    $("passcodeForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      $("passcodeError").classList.add("hidden");
      try {
        await apiFetch("/api/unlock", {
          method: "POST",
          body: { passcode: $("passcodeInput").value },
        });
        $("passcodeInput").value = "";
        await refreshStatus();
      } catch (err) {
        $("passcodeError").textContent = err.message;
        $("passcodeError").classList.remove("hidden");
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initEvents();
    refreshStatus();
  });
})();
